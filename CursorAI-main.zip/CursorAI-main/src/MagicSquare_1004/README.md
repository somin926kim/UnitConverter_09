# MagicSquare_1004

4×4 **부분 마방진**(빈칸 2개) 과제에서 **10선(행·열·대각선) 합=34** 판정을 빠짐없이 검증하기 위한 TDD 프로젝트입니다.

> Mom Test에서 출발: 행·열만 맞추고 대각선 검증을 빠뜨려 **약 20분**을 추가로 쓴 경험을, **기계적·재현 가능한 판정**으로 바꾸는 것이 목표입니다.

## 진짜 문제 (한 문장)

손으로 빈칸 2개를 채울 때 행·열 합은 맞췄지만 **10선 중 하나**를 검증에서 빠뜨려, 틀린 상태를 끝까지 못 잡고 시간을 낭비한다.

## 도메인

| 항목 | 값 |
|------|-----|
| 격자 | 4×4 |
| 숫자 | 1~16 (중복 없음) |
| 빈칸 | **정확히 2개** (`0`) |
| 마법 상수 | **34** |
| 검증 대상 | **10선** — 행 4 + 열 4 + `\` + `/` |
| 성공 출력 | `int[6]` → `[r1, c1, n1, r2, c2, n2]` (좌표 **1-index**) |

도메인 상수 SSOT: [`src/entity/constants.py`](src/entity/constants.py) (`MAGIC_CONSTANT`, `GRID_SIZE`, `MAX_CELL_VALUE`, `BLANK_CELL_VALUE`)

## 성공 기준 (Mom Test)

| ID | 기준 |
|----|------|
| SC-1 | **10선 합 전부** 계산·검증 (행·열만 X) |
| SC-2 | 한 줄이라도 ≠34 → **실패 + 깨진 줄 식별** |
| SC-3 | 동일 유형 문제에서 원인 특정 **1분 이내** |

## 아키텍처

- **ECB:** `boundary → control → entity`
- **Dual-Track TDD:** Logic Track (`entity`, `control`) + UI Track (`boundary`)
- **RED 우선:** pytest FAIL 확인 → GREEN → REFACTOR

| Track | Layer | 테스트 ID | 디렉터리 | Mock |
|-------|-------|-----------|----------|------|
| Logic | entity, control | `D-*` | `tests/entity/`, `tests/control/` | Domain Mock **금지** |
| UI | boundary | `U-*` | `tests/boundary/` | entity/control Mock **허용** |

헌법: [`.cursorrules`](.cursorrules) · TDD: [`magic-square-tdd`](.cursor/skills/magic-square-tdd/SKILL.md) · 문서 Export: [`magic-square-docs`](.cursor/skills/magic-square-docs/SKILL.md)

## 개발 환경

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate  /  bash: source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest tests/ -v
```

| Phase | pytest 예시 |
|-------|-------------|
| entity 전체 | `python -m pytest tests/entity/ -v` |
| D-LOC-01 | `python -m pytest tests/entity/test_d_loc_01.py -v` |
| D-SOL-01 + golden | `python -m pytest tests/entity/test_d_sol_01.py::test_d_sol_01_step_a_success -v` |
| Golden 기준 갱신 (의도적만) | `UPDATE_GOLDEN=1 python -m pytest tests/entity/test_d_sol_01.py::test_d_sol_01_step_a_success -v` |
| REFACTOR (Logic) | `python -m pytest tests/entity tests/control -v` |
| REFACTOR (UI) | `python -m pytest tests/boundary -v` |

## Cursor 워크플로

| Command | 역할 |
|---------|------|
| `/red-test-plan` | RED 설계표 · C2C · pytest 계획 (`tests/`·`src/` 미작성) |
| `/red-skeleton` | RED 스켈레톤 — `tests/`만, `pytest.fail("RED: …")` |
| `/tdd-red` | AAA 실패 테스트 작성 → pytest FAIL |
| `/green-minimal` | RED 1묶음 최소 GREEN |
| `/golden-master` | Approval Test · `tests/golden/*.approved.txt` |
| `/refactor-smell` | 스멜 탐지 (분석만, 코드 수정 없음) |
| `/refactor-safe` | 구조 개선 (계약·golden 유지) |
| `/review-ecb` | ECB·계약 리뷰 (코드 수정 없음) |
| `/export-session` | ARRR Repeat(⑧) — Report·Transcript Export (STEP 1~12) |

Hook: `sessionStart` · `postToolUse(Write)` → pytest 힌트 주입 ([`.cursor/hooks/`](.cursor/hooks/))

## 테스트 ID (C2C)

Logic Track (`D-*`) — 상세: [reference.md](.cursor/skills/magic-square-tdd/reference.md)

| ID | PRD | Layer | 요약 | 상태 |
|----|-----|-------|------|------|
| D-VAL-01~05 | FR-VAL-01~05 | entity | 행·열·`\`·`/`·10선 합 = 34 | ⏳ |
| D-LOC-01 | FR-LOC-01 | entity | 빈칸 2곳 좌표 (1-index) | ✅ GREEN |
| D-SOL-01 | FR-SOL-01 | entity | 빈칸 대입 풀이 (G1 Step A) | ✅ GREEN + golden |

UI Track (`U-*`) — boundary 입력·출력

| ID | PRD | 요약 | 상태 |
|----|-----|------|------|
| U-IN-01~05 | FR-IN-01~05 | 입력 검증 (None, 크기, 범위, 빈칸 수, 중복) | ⏳ |
| U-OUT-01~02 | FR-OUT-01~02 | 성공/실패 출력 표현 | ⏳ |

## 프로젝트 구조

```
MagicSquare_1004/
├── .cursorrules
├── pyproject.toml
├── README.md
├── docs/
│   └── PRD.md
├── Report/                          # 세션별 보고서 (01~08)
├── Prompting/                       # 세션별 Transcript (01~08)
├── .cursor/
│   ├── commands/                    # /tdd-red, /green-minimal, /refactor-smell, …
│   ├── hooks/                       # session-init, pytest 힌트
│   └── skills/
│       ├── magic-square-tdd/
│       └── magic-square-docs/
├── src/
│   └── entity/
│       ├── constants.py             # SSOT (34, 16, 4, 0)
│       ├── loc.py                   # find_blank_coords
│       └── sol.py                   # solution (10선 검증)
├── tests/
│   ├── conftest.py                  # grid_g1 fixture
│   ├── _approval.py                 # assert_matches_golden
│   ├── golden/
│   │   └── d_sol_01_g1_step_a.approved.txt
│   └── entity/
│       ├── test_d_loc_01.py
│       └── test_d_sol_01.py
└── tests/control/ · tests/boundary/  # ⏳ 예정
```

## 문서

| 문서 | 설명 |
|------|------|
| [docs/PRD.md](docs/PRD.md) | PRD — 기능 요구사항, 에러 코드, C2C 추적 |
| [Report/01](Report/01.MagicSquare_ProblemDefinition_Report.md) | Mom Test · R-G-I-O · 범위 |
| [Report/02](Report/02.MagicSquare_Session3_CursorDesign_Report.md) | Cursor 8계층 · Rule/Skill/Command/Hook |
| [Report/03~05](Report/) | RED Test Plan · Skeleton · GREEN (D-LOC-01) |
| [Report/06](Report/06.MagicSquare_Session7_GREEN_GoldenMaster_Report.md) | D-SOL-01 GREEN · Golden Master |
| [Report/07](Report/07.MagicSquare_Session8_REFACTOR_Smell_Report.md) | REFACTOR 스멜 탐지 · safe 후보 |
| [Report/08](Report/08.MagicSquare_Session9_REFACTOR_Safe_Report.md) | REFACTOR safe — 10선 행·열 합 추출 |

## 범위

**In**
- 4×4, 빈칸 2개, 10선=34 판정
- 빈칸 좌표 탐색, 후보 값 검증
- Cursor Rule / Skill / Command / Hook / Test Loop

**Out**
- PyQt 완성 앱 · 배포 (1차 목표 아님)
- 3×3 / 5×5 · 마방진 자동 생성
- "대충 맞는 것 같다" 수동 확인만으로 완료 처리

## 에러 코드

| 코드 | 의미 | 담당 |
|------|------|------|
| E001 | 잘못된 격자 크기 | boundary |
| E002 | 빈칸 개수 ≠ 2 | boundary |
| E003 | Null / 범위 / 중복 위반 | boundary |
| E004 | 특정 줄 합 ≠ 34 | boundary |
| E005 | 입·출력 계약 위반 | boundary |
| E006 | 해 없음 / 풀이 불가 | entity → boundary 매핑 |
| E007 | 해 다중 / 모호 | entity → boundary 매핑 |

entity는 E001~E005 **raise·반환·처리 금지** — 순수 도메인(10선 판정·풀이)만.

## 현재 상태 · 다음 단계

| 항목 | 상태 |
|------|------|
| `.cursorrules` · Skill · Command · Hook | ✅ |
| `pyproject.toml` · pytest harness | ✅ |
| `src/entity` — `constants`, `loc`, `sol` | ✅ |
| `tests/entity` — D-LOC-01, D-SOL-01 | ✅ **2 passed** |
| Golden Master (D-SOL-01 G1 Step A) | ✅ matched |
| `/refactor-smell` (P1: 10선 합 중복) | ✅ 분석 완료 |
| `/refactor-safe` (P1: `sum_row`/`sum_col`) | ✅ golden matched |
| `src/control` · `src/boundary` · D-VAL · U-* | ⏳ |
| PyQt UI | ❌ (범위 외) |

**다음 작업**

1. `/refactor-safe` (선택) — 대각선 합 또는 `solution` 책임 분리
2. `/red-skeleton` — D-VAL-03~05 (대각선·10선) 또는 U-IN-01/02
3. D-SOL Step B — E006/E007 (별도 RED/GREEN 사이클)
